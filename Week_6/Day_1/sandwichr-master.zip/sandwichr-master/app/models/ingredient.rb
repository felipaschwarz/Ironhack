class Ingredient < ActiveRecord::Base
end
