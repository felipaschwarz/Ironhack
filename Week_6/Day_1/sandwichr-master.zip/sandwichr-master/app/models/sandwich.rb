class Sandwich < ActiveRecord::Base
end
