class Api::V1::Task < ActiveRecord::Base
end
