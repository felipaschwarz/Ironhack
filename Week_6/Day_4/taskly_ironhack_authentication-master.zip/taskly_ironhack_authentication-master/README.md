#Taskly

example app with basic user authentication to be used as a starting point for exercises