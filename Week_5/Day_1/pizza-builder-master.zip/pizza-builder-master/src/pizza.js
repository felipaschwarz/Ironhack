$(document).on('ready', function () {
	$('.btn-pepperonni').toggleClass('active');
	$('.btn-mushrooms').toggleClass('active');
	$('.btn-green-peppers').toggleClass('active');
	$('.sauce').toggleClass('sauce-white');
	$('.crust').toggleClass('crust-gluten-free');

	$('.btn-pepperonni').on('click', function () {
		$('.pep').fadeToggle();
		$('.btn-pepperonni').toggleClass('active');
		
		if ($('#pizza').hasClass('active')) {
			alert("hello pepperoni")
			$("aside.panel strong").text("$" + (parseInt(($("aside.panel strong").text()).replace("$","")) - 1))
		};
	});

	$('.btn-mushrooms').on('click', function () {
		$('.mushroom').fadeToggle();
		$('.btn-mushrooms').toggleClass('active');
	});

	$('.btn-green-peppers').on('click', function () {
		$('.green-pepper').fadeToggle();
		$('.btn-green-peppers').toggleClass('active');
	});

	$('.btn-sauce').on('click', function () {
		$('.sauce').toggleClass('sauce-white');
		$('.btn-sauce').toggleClass('active');
	});

	$('.btn-crust').on('click', function () {
		$('.crust').toggleClass('crust-gluten-free');
		$('.btn-crust').toggleClass('active');
	});
});

// if ( $('#pizza').hasClass( ".pep" ) ) {
// 	$("aside.panel strong").text(parseInt(("aside.panel strong").text().replace("$","")) - 1)
// }